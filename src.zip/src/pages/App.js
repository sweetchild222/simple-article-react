// App.js
import React, { useState, useCallback } from 'react';
import ToastContainer from './ToastContainer';
import '../css/App.css'; // For general app styling

function App() {
  const [toasts, setToasts] = useState([]);

  const addToast = useCallback((message, type = 'info') => {    
    const id = Date.now();
    setToasts((prevToasts) => [...prevToasts, { id, message, type }]);
  }, []);

  const removeToast = useCallback((id) => {

    console.log('remove toast', id)

    setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== id));
  }, []);

  return (
    <div className="App">
      <h1>Custom React Toasts</h1>
      <button onClick={() => addToast('Success message!', 'success')}>
        Show Success Toast
      </button>
      <button onClick={() => addToast('Error message!', 'error')}>
        Show Error Toast
      </button>
      <ToastContainer toasts={toasts} removeToast={removeToast} />
    </div>
  );
}

export default App;