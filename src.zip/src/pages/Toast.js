// components/Toast.jsx
import React, { useEffect } from 'react';
import './Toast.css';

const Toast = ({ message, type, onClose}) => {
        
    useEffect(() => {
        const timer = setTimeout(() => {

            onClose()

            console.log('asdfafs')

        }, 3000)

    return () => clearTimeout(timer)

    }, [onClose])

  return (
    <div className={`toast toast-${type}`}>
      <span>{message}</span>
      <button onClick={onClose}>&times;</button>
    </div>
  );
};

export default Toast;