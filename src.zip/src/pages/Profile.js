import axios from 'axios';

import React, {useContext, useEffect } from "react";


import * as api from '../util/Api.js'
import { useState } from 'react';
import { BrowserRouter, Routes, Route, useNavigate, useLocation} from 'react-router-dom';
import * as validator from '../util/Validator.js'

import AuthContext from "../util/AuthContext.js";


export default function() {

    console.log('home')
    const {auth, updateAuth, validAuth, removeAuth} = useContext(AuthContext)
    const [isLoggedIn, setIsLoggedIn] = useState(true);
    
    const navigate = useNavigate();

    useEffect(() => {
        
        setIsLoggedIn(validAuth(auth))

    }, [auth]);


    useEffect(() => {

        console.log(isLoggedIn)

        if(isLoggedIn){

            console.log('weee')

            
        }
        else
            navigate('/home', {replace:true})
        


    }, [isLoggedIn])


    
    const onClickLogout = async(event)=>{

        removeAuth()
    }


    const onClickPasswordChange = async(event)=>{

        navigate('/changePassword')
    }


    const onClickUserWithdraw = async() =>{

        const password = input_widthdraw_password.value

        if(password == '')
            return

        const resPasswordCheck = await api.getUserPasswordCheck(auth.jwt, auth.user_id, password)

        if(resPasswordCheck == null)
            return

        if(resPasswordCheck.correct == false)
            return

        const payload = {withdraw:true}

        const resUser = await api.patchUser(auth.jwt, auth.user_id, payload)

        if(resUser == null)
            return

        console.log(resUser)

        removeAuth()
    }


    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>

        <img src="/images/user.png" alt='logo image' height='100px' width='100px'/>
        <button id="btn_logout" onClick={onClickLogout} >로그아웃</button>
        <button id="btn_passwordChange" onClick={onClickPasswordChange} >비밀번호 변경</button>

        <label htmlFor="input_widthdraw_password">Password</label>
        <input id="input_widthdraw_password" type="text"/>
        <button id="btn_userLeave" onClick={onClickUserWithdraw} >회원탈퇴</button> 
      </div>
    );  
}

